namespace Support
{
    public class Printer
    {
        public void CheckSerializable(object obj)
        {
            Type type = null; //obtém aqui o tipo do objeto
            var serAttribute = type.GetCustomAttributes(true).FirstOrDefault(x => x.GetType() == typeof(SerializableAttribute));
            if (serAttribute == default)
            {
                //lança a exceção
            }
        }
    }

    public class Car
    {
        public int WheelCount { get; set; }
    }


    public struct Pos
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Pos(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
    