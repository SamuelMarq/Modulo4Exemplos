﻿using System;
using Worksheet27.Enumerables;

namespace Worksheet27.Model
{
    public class Car
    {
        public Color Color { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Ano { get; set; }
        public bool Ativo { get; set; }
        public string LicensePlate { get; set; }

        public void AA()
        {
            "sadmaso".
        }
    }
}
