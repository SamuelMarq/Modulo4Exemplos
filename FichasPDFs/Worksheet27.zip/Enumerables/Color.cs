﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Worksheet27.Enumerables
{
    public enum Color
    {
        White,
        Black,
        Red,
        Yellow,
        Blue
    }
}
